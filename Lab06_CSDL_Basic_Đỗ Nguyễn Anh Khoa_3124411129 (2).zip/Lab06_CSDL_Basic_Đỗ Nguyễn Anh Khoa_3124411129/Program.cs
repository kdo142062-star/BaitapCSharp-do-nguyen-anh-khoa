using System;
using System.Windows.Forms;

namespace Lab06_CSDL_Basic
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Khởi chạy Form Menu tổng (chứa cả Lab 6a và Lab 6b)
            Application.Run(new frmMain());
        }
    }
}