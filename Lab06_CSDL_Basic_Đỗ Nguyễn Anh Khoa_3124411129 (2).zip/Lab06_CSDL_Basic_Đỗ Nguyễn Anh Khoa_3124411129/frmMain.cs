using System;
using System.Drawing;
using System.Windows.Forms;
using thuc_hanh_6a;
using thuc_hanh_6b;

namespace Lab06_CSDL_Basic
{
    public partial class frmMain : Form
    {
        private Button btnLab6a, btnLab6b, btnExit;

        public frmMain()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Menu Tổng - Thực Hành Lab 06";
            this.Size = new Size(360, 270);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Nút mở Lab 6a
            btnLab6a = new Button();
            btnLab6a.Text = "Lab 6a: Quản lý Lớp";
            btnLab6a.Location = new Point(40, 30);
            btnLab6a.Size = new Size(260, 40);
            btnLab6a.Click += (s, e) => {
                frmLop frm = new frmLop();
                frm.ShowDialog();
            };

            // Nút mở Lab 6b
            btnLab6b = new Button();
            btnLab6b.Text = "Lab 6b: Quản lý Cửa Hàng";
            btnLab6b.Location = new Point(40, 85);
            btnLab6b.Size = new Size(260, 40);
            btnLab6b.Click += (s, e) => {
                frmCuaHangMain frm = new frmCuaHangMain();
                frm.ShowDialog();
            };

            // Nút Thoát
            btnExit = new Button();
            btnExit.Text = "Thoát ứng dụng";
            btnExit.Location = new Point(40, 140);
            btnExit.Size = new Size(260, 40);
            btnExit.Click += (s, e) => Application.Exit();

            this.Controls.Add(btnLab6a);
            this.Controls.Add(btnLab6b);
            this.Controls.Add(btnExit);
        }
    }
}