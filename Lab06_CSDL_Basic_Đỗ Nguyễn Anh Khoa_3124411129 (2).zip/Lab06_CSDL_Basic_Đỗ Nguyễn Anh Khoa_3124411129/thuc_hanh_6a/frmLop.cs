using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace thuc_hanh_6a
{
    public partial class frmLop : Form
    {
        private Label lblMaKhoa, lblMaLop, lblTenLop;
        private TextBox txtMaKhoa, txtMaLop, txtTenLop;
        private Button btnThem, btnXoa, btnSua;
        
        // Chuỗi kết nối SQL Server
        private string connString = @"Server=.\SQLEXPRESS;Database=QLSINHVIEN;Trusted_Connection=True;TrustServerCertificate=True;";

        public frmLop()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmLop";
            this.Size = new Size(410, 245);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Lấy trực tiếp icon chuẩn gốc của hệ thống Windows Forms
            this.Icon = System.Drawing.SystemIcons.Application;

            lblMaKhoa = new Label() { Text = "Mã khoa", Location = new Point(25, 25), AutoSize = true, Font = new Font("Arial", 9) };
            txtMaKhoa = new TextBox() { Location = new Point(100, 22), Size = new Size(260, 25), Font = new Font("Arial", 10) };
            txtMaKhoa.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) {
                    txtMaLop.Focus();
                    e.Handled = true; e.SuppressKeyPress = true;
                }
            };

            lblMaLop = new Label() { Text = "Mã lớp", Location = new Point(25, 65), AutoSize = true, Font = new Font("Arial", 9) };
            txtMaLop = new TextBox() { Location = new Point(100, 62), Size = new Size(260, 25), Font = new Font("Arial", 10) };
            txtMaLop.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) {
                    txtTenLop.Focus();
                    e.Handled = true; e.SuppressKeyPress = true;
                }
            };

            lblTenLop = new Label() { Text = "Tên lớp", Location = new Point(25, 105), AutoSize = true, Font = new Font("Arial", 9) };
            txtTenLop = new TextBox() { Location = new Point(100, 102), Size = new Size(260, 25), Font = new Font("Arial", 10) };
            txtTenLop.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) {
                    BtnThem_Click(s, e);
                    e.Handled = true; e.SuppressKeyPress = true;
                }
            };

            int btnY = 150;
            int btnWidth = 85;
            int btnHeight = 32;

            btnThem = new Button() { Text = "Thêm", Location = new Point(55, btnY), Size = new Size(btnWidth, btnHeight), Font = new Font("Arial", 9) };
            btnThem.Click += BtnThem_Click;

            btnXoa = new Button() { Text = "Xóa", Location = new Point(155, btnY), Size = new Size(btnWidth, btnHeight), Font = new Font("Arial", 9) };
            btnXoa.Click += BtnXoa_Click;

            btnSua = new Button() { Text = "Sửa", Location = new Point(255, btnY), Size = new Size(btnWidth, btnHeight), Font = new Font("Arial", 9) };
            btnSua.Click += BtnSua_Click;

            this.Controls.AddRange(new Control[] {
                lblMaKhoa, txtMaKhoa,
                lblMaLop, txtMaLop,
                lblTenLop, txtTenLop,
                btnThem, btnXoa, btnSua
            });
        }

        private void BtnThem_Click(object? sender, EventArgs e)
        {
            string maKhoa = txtMaKhoa.Text.Trim();
            string maLop = txtMaLop.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (string.IsNullOrEmpty(maKhoa) || string.IsNullOrEmpty(maLop) || string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Mã khoa, Mã lớp và Tên lớp không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btnThem.Enabled = false;
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "INSERT INTO Lop (MaKhoa, MaLop, TenLop) VALUES (@MaKhoa, @MaLop, @TenLop)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);
                        cmd.Parameters.AddWithValue("@MaLop", maLop);
                        cmd.Parameters.AddWithValue("@TenLop", tenLop);
                        
                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Thêm mới lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearInputs();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnThem.Enabled = true;
            }
        }

        private void BtnXoa_Click(object? sender, EventArgs e)
        {
            string maLop = txtMaLop.Text.Trim();
            string maKhoa = txtMaKhoa.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (string.IsNullOrEmpty(maLop))
            {
                MessageBox.Show("Mã lớp không được để trống khi xóa!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaLop.Focus();
                return;
            }

            if (!string.IsNullOrEmpty(maKhoa) || !string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Khi xóa, chỉ được nhập Mã lớp, Mã khoa và Tên lớp phải để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show($"Bạn có chắc muốn xóa lớp có mã '{maLop}' không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                btnXoa.Enabled = false;
                try
                {
                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        conn.Open();
                        string query = "DELETE FROM Lop WHERE MaLop = @MaLop";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@MaLop", maLop);
                            int rows = cmd.ExecuteNonQuery();
                            if (rows > 0)
                            {
                                MessageBox.Show("Xóa lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearInputs();
                            }
                            else
                            {
                                MessageBox.Show("Không tìm thấy Mã lớp cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    btnXoa.Enabled = true;
                }
            }
        }

        private void BtnSua_Click(object? sender, EventArgs e)
        {
            string maLop = txtMaLop.Text.Trim();
            string maKhoa = txtMaKhoa.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (string.IsNullOrEmpty(maLop))
            {
                MessageBox.Show("Mã lớp không được để trống khi sửa!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaLop.Focus();
                return;
            }

            if (string.IsNullOrEmpty(maKhoa) && string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Phải nhập ít nhất Mã khoa hoặc Tên lớp cần thay đổi!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btnSua.Enabled = false;
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "UPDATE Lop SET ";
                    bool hasUpdate = false;

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.Parameters.AddWithValue("@MaLop", maLop);

                        if (!string.IsNullOrEmpty(maKhoa))
                        {
                            query += "MaKhoa = @MaKhoa";
                            cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);
                            hasUpdate = true;
                        }

                        if (!string.IsNullOrEmpty(tenLop))
                        {
                            if (hasUpdate) query += ", ";
                            query += "TenLop = @TenLop";
                            cmd.Parameters.AddWithValue("@TenLop", tenLop);
                        }

                        query += " WHERE MaLop = @MaLop";
                        cmd.CommandText = query;

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Cập nhật thông tin lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearInputs();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy Mã lớp cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnSua.Enabled = true;
            }
        }

        private void ClearInputs()
        {
            txtMaKhoa.Clear();
            txtMaLop.Clear();
            txtTenLop.Clear();
            txtMaKhoa.Focus();
        }
    }
}