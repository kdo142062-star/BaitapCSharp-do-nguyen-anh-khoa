using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace thuc_hanh_6b
{
    public partial class frmCuaHangMain : Form
    {
        private Button btnTonKho, btnThemSP, btnBanHang, btnDong;
        private string connString = @"Server=.\SQLEXPRESS;Database=QLCuaHang;Trusted_Connection=True;TrustServerCertificate=True;";

        public frmCuaHangMain()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Hệ Thống Quản Lý Cửa Hàng - Lab 6b";
            this.Size = new Size(360, 310);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Nút Tạo tồn kho
            btnTonKho = new Button();
            btnTonKho.Text = "Tạo tồn kho hôm nay";
            btnTonKho.Location = new Point(40, 25);
            btnTonKho.Size = new Size(260, 40);
            btnTonKho.Click += BtnTonKho_Click;

            // Nút Thêm sản phẩm
            btnThemSP = new Button();
            btnThemSP.Text = "Thêm sản phẩm mới";
            btnThemSP.Location = new Point(40, 80);
            btnThemSP.Size = new Size(260, 40);
            btnThemSP.Click += (s, e) => {
                frmThemSanPham frm = new frmThemSanPham();
                frm.ShowDialog();
            };

            // Nút Bán hàng
            btnBanHang = new Button();
            btnBanHang.Text = "Bán hàng";
            btnBanHang.Location = new Point(40, 135);
            btnBanHang.Size = new Size(260, 40);
            btnBanHang.Click += (s, e) => {
                frmBanHang frm = new frmBanHang();
                frm.ShowDialog();
            };

            // Nút Đóng form
            btnDong = new Button();
            btnDong.Text = "Đóng";
            btnDong.Location = new Point(40, 190);
            btnDong.Size = new Size(260, 40);
            btnDong.Click += (s, e) => this.Close();

            this.Controls.Add(btnTonKho);
            this.Controls.Add(btnThemSP);
            this.Controls.Add(btnBanHang);
            this.Controls.Add(btnDong);
        }

        private void BtnTonKho_Click(object? sender, EventArgs e)
        {
            DateTime ngayHienTai = DateTime.Today;
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string checkQuery = "SELECT COUNT(*) FROM TONKHO WHERE NgayTon = @NgayHienTai";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@NgayHienTai", ngayHienTai);
                        int countToday = (int)checkCmd.ExecuteScalar();
                        if (countToday > 0)
                        {
                            MessageBox.Show("Tồn kho ngày " + ngayHienTai.ToString("dd/MM/yyyy") + " đã được tạo trước đó!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }

                    string querySP = "SELECT MaSP FROM SANPHAM";
                    DataTable dtSP = new DataTable();
                    using (SqlDataAdapter da = new SqlDataAdapter(querySP, conn))
                    {
                        da.Fill(dtSP);
                    }

                    foreach (DataRow row in dtSP.Rows)
                    {
                        int maSP = Convert.ToInt32(row["MaSP"]);
                        int slDauMoi = 0;

                        string queryPrev = "SELECT TOP 1 (SLDau + SLNhap - SLBan) AS SLTonCu FROM TONKHO WHERE MaSP = @MaSP ORDER BY NgayTon DESC";
                        using (SqlCommand cmdPrev = new SqlCommand(queryPrev, conn))
                        {
                            cmdPrev.Parameters.AddWithValue("@MaSP", maSP);
                            object result = cmdPrev.ExecuteScalar();
                            if (result != null && result != DBNull.Value)
                            {
                                slDauMoi = Convert.ToInt32(result);
                            }
                        }

                        string insertTon = "INSERT INTO TONKHO (MaSP, NgayTon, SLDau, SLNhap, SLBan) VALUES (@MaSP, @NgayTon, @SLDau, 0, 0)";
                        using (SqlCommand cmdInsert = new SqlCommand(insertTon, conn))
                        {
                            cmdInsert.Parameters.AddWithValue("@MaSP", maSP);
                            cmdInsert.Parameters.AddWithValue("@NgayTon", ngayHienTai);
                            cmdInsert.Parameters.AddWithValue("@SLDau", slDauMoi);
                            cmdInsert.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Khởi tạo tồn kho hôm nay thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}