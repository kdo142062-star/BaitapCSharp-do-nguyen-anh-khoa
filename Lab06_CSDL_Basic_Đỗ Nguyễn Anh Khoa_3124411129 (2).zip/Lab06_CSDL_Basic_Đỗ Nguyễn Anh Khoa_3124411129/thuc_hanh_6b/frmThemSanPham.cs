using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace thuc_hanh_6b
{
    public partial class frmThemSanPham : Form
    {
        private Label lblTenSP;
        private TextBox txtTenSP;
        private Button btnThem, btnThoat;
        private string connString = @"Server=.\SQLEXPRESS;Database=QLCuaHang;Trusted_Connection=True;TrustServerCertificate=True;";

        public frmThemSanPham()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Thêm sản phẩm mới";
            this.Size = new Size(380, 180);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Icon = SystemIcons.Application;

            lblTenSP = new Label() { Text = "Tên sản phẩm", Location = new Point(25, 30), AutoSize = true, Font = new Font("Arial", 9) };
            txtTenSP = new TextBox() { Location = new Point(125, 27), Size = new Size(200, 25), Font = new Font("Arial", 10) };

            btnThem = new Button() { Text = "Thêm", Location = new Point(70, 80), Size = new Size(90, 30), Font = new Font("Arial", 9) };
            btnThem.Click += BtnThem_Click;

            btnThoat = new Button() { Text = "Thoát", Location = new Point(190, 80), Size = new Size(90, 30), Font = new Font("Arial", 9) };
            btnThoat.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { lblTenSP, txtTenSP, btnThem, btnThoat });
        }

        private void BtnThem_Click(object? sender, EventArgs e)
        {
            string tenSP = txtTenSP.Text.Trim();
            if (string.IsNullOrEmpty(tenSP))
            {
                MessageBox.Show("Tên sản phẩm không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTenSP.Focus();
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string querySP = "INSERT INTO SANPHAM (TenSP) VALUES (@TenSP); SELECT SCOPE_IDENTITY();";
                    int newMaSP = 0;
                    using (SqlCommand cmdSP = new SqlCommand(querySP, conn))
                    {
                        cmdSP.Parameters.AddWithValue("@TenSP", tenSP);
                        newMaSP = Convert.ToInt32(cmdSP.ExecuteScalar());
                    }

                    string queryTon = "INSERT INTO TONKHO (MaSP, NgayTon, SLDau, SLNhap, SLBan) VALUES (@MaSP, @NgayTon, 0, 0, 0)";
                    using (SqlCommand cmdTon = new SqlCommand(queryTon, conn))
                    {
                        cmdTon.Parameters.AddWithValue("@MaSP", newMaSP);
                        cmdTon.Parameters.AddWithValue("@NgayTon", DateTime.Today);
                        cmdTon.ExecuteNonQuery();
                    }

                    MessageBox.Show("Thêm sản phẩm mới và khởi tạo tồn kho thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtTenSP.Clear();
                    txtTenSP.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}