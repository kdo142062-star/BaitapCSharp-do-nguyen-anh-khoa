using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace thuc_hanh_6b
{
    public partial class frmBanHang : Form
    {
        private Button btnTaoHoaDon, btnThemCT, btnHuy, btnThanhToan;
        private Label lblChiTiet, lblMaHD, lblMaSP, lblSoLuong;
        private TextBox txtMaHD, txtSoLuong;
        private ComboBox cboSanPham;
        private Panel pnlChiTiet;

        private int currentMaHD = -1;
        private string connString = @"Server=.\SQLEXPRESS;Database=QLCuaHang;Trusted_Connection=True;TrustServerCertificate=True;";

        public frmBanHang()
        {
            InitializeComponentCustom();
            SetControlState(false);
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Bán hàng";
            this.Size = new Size(520, 360);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Icon = SystemIcons.Application;

            btnTaoHoaDon = new Button() { Text = "Tạo hóa đơn mới", Location = new Point(320, 20), Size = new Size(150, 32), Font = new Font("Arial", 9, FontStyle.Bold) };
            btnTaoHoaDon.Click += BtnTaoHoaDon_Click;

            lblChiTiet = new Label() { Text = "Chi tiết hóa đơn", Location = new Point(30, 60), AutoSize = true, Font = new Font("Arial", 9, FontStyle.Bold) };

            pnlChiTiet = new Panel() { Location = new Point(30, 85), Size = new Size(440, 210), BorderStyle = BorderStyle.FixedSingle };

            lblMaHD = new Label() { Text = "Mã hóa đơn", Location = new Point(20, 20), AutoSize = true };
            txtMaHD = new TextBox() { Location = new Point(130, 17), Size = new Size(180, 23), ReadOnly = true, BackColor = Color.LightGray };

            lblMaSP = new Label() { Text = "Sản phẩm", Location = new Point(20, 60), AutoSize = true };
            cboSanPham = new ComboBox() { Location = new Point(130, 57), Size = new Size(180, 23), DropDownStyle = ComboBoxStyle.DropDownList };

            lblSoLuong = new Label() { Text = "Số lượng", Location = new Point(20, 100), AutoSize = true };
            txtSoLuong = new TextBox() { Location = new Point(130, 97), Size = new Size(180, 23) };

            btnThemCT = new Button() { Text = "Thêm", Location = new Point(130, 145), Size = new Size(80, 30) };
            btnThemCT.Click += BtnThemCT_Click;

            btnHuy = new Button() { Text = "Hủy", Location = new Point(230, 145), Size = new Size(80, 30) };
            btnHuy.Click += (s, e) => SetControlState(false);

            btnThanhToan = new Button() { Text = "Thanh toán", Location = new Point(330, 145), Size = new Size(90, 30), BackColor = Color.LightGreen };
            btnThanhToan.Click += BtnThanhToan_Click;

            pnlChiTiet.Controls.AddRange(new Control[] {
                lblMaHD, txtMaHD,
                lblMaSP, cboSanPham,
                lblSoLuong, txtSoLuong,
                btnThemCT, btnHuy, btnThanhToan
            });

            this.Controls.AddRange(new Control[] { btnTaoHoaDon, lblChiTiet, pnlChiTiet });
        }

        private void SetControlState(bool enabled)
        {
            pnlChiTiet.Enabled = enabled;
            if (!enabled)
            {
                txtMaHD.Clear();
                txtSoLuong.Clear();
                currentMaHD = -1;
            }
        }

        private void LoadSanPhamToCombo()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "SELECT MaSP, TenSP FROM SANPHAM";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    cboSanPham.DataSource = dt;
                    cboSanPham.DisplayMember = "TenSP";
                    cboSanPham.ValueMember = "MaSP";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnTaoHoaDon_Click(object? sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "INSERT INTO HOADON (NgayTao, TinhTrangThanhToan) VALUES (GETDATE(), 0); SELECT SCOPE_IDENTITY();";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        currentMaHD = Convert.ToInt32(cmd.ExecuteScalar());
                        txtMaHD.Text = currentMaHD.ToString();
                    }
                }

                LoadSanPhamToCombo();
                SetControlState(true);
                MessageBox.Show("Tạo hóa đơn thành công! Mã HĐ: " + currentMaHD, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnThemCT_Click(object? sender, EventArgs e)
        {
            if (currentMaHD == -1 || cboSanPham.SelectedValue == null) return;

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuongBan) || soLuongBan <= 0)
            {
                MessageBox.Show("Số lượng bán phải lớn hơn 0!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoLuong.Focus();
                return;
            }

            int maSP = Convert.ToInt32(cboSanPham.SelectedValue);
            DateTime ngayHienTai = DateTime.Today;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string queryTon = "SELECT TOP 1 (SLDau + SLNhap - SLBan) AS TonHienTai FROM TONKHO WHERE MaSP = @MaSP AND NgayTon = @NgayTon";
                    int slTonKho = 0;
                    using (SqlCommand cmdTon = new SqlCommand(queryTon, conn))
                    {
                        cmdTon.Parameters.AddWithValue("@MaSP", maSP);
                        cmdTon.Parameters.AddWithValue("@NgayTon", ngayHienTai);
                        object result = cmdTon.ExecuteScalar();
                        if (result == null || result == DBNull.Value)
                        {
                            MessageBox.Show("Chưa tạo tồn kho cho ngày hôm nay! Vui lòng bấm 'Tạo tồn kho hôm nay' ở menu chính trước.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        slTonKho = Convert.ToInt32(result);
                    }

                    if (soLuongBan > slTonKho)
                    {
                        MessageBox.Show($"Số lượng bán ({soLuongBan}) vượt quá tồn kho khả dụng ({slTonKho})!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string queryInsertCT = "INSERT INTO CHITIET_HOADON (MaHD, MaSP, SoLuong) VALUES (@MaHD, @MaSP, @SoLuong)";
                    using (SqlCommand cmdInsert = new SqlCommand(queryInsertCT, conn))
                    {
                        cmdInsert.Parameters.AddWithValue("@MaHD", currentMaHD);
                        cmdInsert.Parameters.AddWithValue("@MaSP", maSP);
                        cmdInsert.Parameters.AddWithValue("@SoLuong", soLuongBan);
                        cmdInsert.ExecuteNonQuery();
                    }

                    string queryUpdateTon = "UPDATE TONKHO SET SLBan = SLBan + @SoLuong WHERE MaSP = @MaSP AND NgayTon = @NgayTon";
                    using (SqlCommand cmdUpdate = new SqlCommand(queryUpdateTon, conn))
                    {
                        cmdUpdate.Parameters.AddWithValue("@SoLuong", soLuongBan);
                        cmdUpdate.Parameters.AddWithValue("@MaSP", maSP);
                        cmdUpdate.Parameters.AddWithValue("@NgayTon", ngayHienTai);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    MessageBox.Show("Thêm chi tiết hóa đơn thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSoLuong.Clear();
                }
            }
            catch (SqlException ex) when (ex.Number == 2627)
            {
                MessageBox.Show("Sản phẩm này đã có trong hóa đơn!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnThanhToan_Click(object? sender, EventArgs e)
        {
            if (currentMaHD == -1) return;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "UPDATE HOADON SET TinhTrangThanhToan = 1 WHERE MaHD = @MaHD";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaHD", currentMaHD);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Thanh toán thành công hóa đơn #" + currentMaHD, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SetControlState(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}