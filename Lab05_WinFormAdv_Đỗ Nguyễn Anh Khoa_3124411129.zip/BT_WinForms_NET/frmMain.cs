using System;
using System.Drawing;
using System.Windows.Forms;

namespace BT_WinForms_NET
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "MENU TỔNG HỢP BÀI TẬP";
            this.Size = new Size(420, 440);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Tiêu đề menu
            Label lblTitle = new Label() {
                Text = "CHƯƠNG TRÌNH BÀI TẬP",
                Font = new Font("Arial", 14, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Location = new Point(85, 15),
                AutoSize = true
            };

            // --- PHẦN 5C ---
            Label lbl5c = new Label() {
                Text = "--- PHẦN 5C ---",
                Font = new Font("Arial", 10, FontStyle.Bold),
                ForeColor = Color.DimGray,
                Location = new Point(140, 50),
                AutoSize = true
            };

            Button btnTuDien = new Button() { Text = "1. Từ điển (Anh-Việt / Việt-Anh)", Location = new Point(50, 75), Width = 300, Height = 35 };
            Button btnListbox = new Button() { Text = "2. Listbox số", Location = new Point(50, 115), Width = 300, Height = 35 };
            Button btnDanhBa = new Button() { Text = "3. Danh bạ (TreeView)", Location = new Point(50, 155), Width = 300, Height = 35 };

            // --- PHẦN 5D ---
            Label lbl5d = new Label() {
                Text = "--- PHẦN 5D ---",
                Font = new Font("Arial", 10, FontStyle.Bold),
                ForeColor = Color.DimGray,
                Location = new Point(140, 205),
                AutoSize = true
            };

            Button btnDongHo = new Button() { Text = "1. Đồng hồ đếm ngược", Location = new Point(50, 230), Width = 300, Height = 35 };
            Button btnLop = new Button() { Text = "2. Quản lý Lớp (SQL Server)", Location = new Point(50, 270), Width = 300, Height = 35 };

            // Nút Thoát
            Button btnThoat = new Button() { Text = "THOÁT", Location = new Point(50, 325), Width = 300, Height = 35 };
            btnThoat.Click += (s, e) => { this.Close(); };

            // Gắn sự kiện mở form tương ứng
            btnTuDien.Click += (s, e) => { new frmTuDien().ShowDialog(); };
            btnListbox.Click += (s, e) => { new frmListboxSo().ShowDialog(); };
            btnDanhBa.Click += (s, e) => { new frmDanhBa().ShowDialog(); };
            btnDongHo.Click += (s, e) => { new frmDongHo().ShowDialog(); };
            btnLop.Click += (s, e) => { new frmLop().ShowDialog(); };

            this.Controls.AddRange(new Control[] { 
                lblTitle, lbl5c, btnTuDien, btnListbox, btnDanhBa, 
                lbl5d, btnDongHo, btnLop, btnThoat 
            });
        }
    }
}