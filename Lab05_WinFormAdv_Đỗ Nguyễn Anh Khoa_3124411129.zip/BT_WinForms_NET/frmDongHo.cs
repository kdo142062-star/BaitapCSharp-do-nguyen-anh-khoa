using System;
using System.Drawing;
using System.Windows.Forms;

namespace BT_WinForms_NET
{
    public partial class frmDongHo : Form
    {
        private Label lblTime;
        private Button btnStart;
        private System.Windows.Forms.Timer timer;
        private int totalSeconds = 30 * 60; // 30 phút đếm ngược

        public frmDongHo()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "Đồng hồ";
            this.Size = new Size(320, 240);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Nhãn hiển thị thời gian (30:00)
            lblTime = new Label() {
                Text = "30:00",
                Font = new Font("Arial", 26, FontStyle.Bold),
                ForeColor = Color.Black,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(40, 35),
                AutoSize = false,
                Size = new Size(220, 50)
            };

            // Nút Bắt đầu
            btnStart = new Button() {
                Text = "Bắt đầu",
                Font = new Font("Arial", 10, FontStyle.Regular),
                Location = new Point(100, 105),
                Size = new Size(100, 35)
            };
            btnStart.Click += BtnStart_Click;

            // Khởi tạo Timer đếm ngược (1000ms = 1 giây)
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;

            this.Controls.AddRange(new Control[] { lblTime, btnStart });
        }

        private void BtnStart_Click(object? sender, EventArgs e)
        {
            btnStart.Enabled = false; // Khóa nút khi đang chạy đếm ngược
            timer.Start();
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            if (totalSeconds > 0)
            {
                totalSeconds--;
                int minutes = totalSeconds / 60;
                int seconds = totalSeconds % 60;
                lblTime.Text = $"{minutes:D2}:{seconds:D2}";
            }
            else
            {
                timer.Stop();
                MessageBox.Show("Đã hết thời gian!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnStart.Enabled = true;
                totalSeconds = 30 * 60; // Reset lại 30 phút
                lblTime.Text = "30:00";
            }
        }
    }
}