using System;
using System.Drawing;
using System.Windows.Forms;

namespace BT_WinForms_NET
{
    public partial class frmDanhBa : Form
    {
        private TreeView treeView;
        private GroupBox groupBox;
        private Label lblFirstName, lblLastName;
        private TextBox txtFirstName, txtLastName;
        private Button btnAdd, btnExit;

        public frmDanhBa()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmBTVN2";
            this.Size = new Size(580, 420);
            this.StartPosition = FormStartPosition.CenterScreen;

            // TreeView chứa các ký tự từ A -> Z ở bên trái[cite: 10]
            treeView = new TreeView()
            {
                Location = new Point(15, 15),
                Size = new Size(220, 320)
            };

            // Khởi tạo các node từ A đến Z[cite: 10]
            for (char c = 'A'; c <= 'Z'; c++)
            {
                treeView.Nodes.Add(c.ToString(), c.ToString());
            }

            // GroupBox chứa các ô nhập liệu ở bên phải[cite: 10]
            groupBox = new GroupBox()
            {
                Text = "",
                Location = new Point(250, 15),
                Size = new Size(290, 200)
            };

            lblFirstName = new Label() { Text = "First Name", Location = new Point(20, 40), AutoSize = true, Font = new Font("Arial", 10) };
            txtFirstName = new TextBox() { Location = new Point(110, 38), Size = new Size(160, 25) };

            // Nhấn Enter ở First Name -> tự động nhảy sang Last Name
            txtFirstName.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter)
                {
                    txtLastName.Focus();
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }
            };

            lblLastName = new Label() { Text = "Last Name", Location = new Point(20, 95), AutoSize = true, Font = new Font("Arial", 10) };
            txtLastName = new TextBox() { Location = new Point(110, 93), Size = new Size(160, 25) };

            // Nhấn Enter ở Last Name -> thực hiện Add ngay lập tức
            txtLastName.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter)
                {
                    BtnAdd_Click(s, e);
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }
            };

            btnAdd = new Button() { Text = "Add", Location = new Point(180, 145), Size = new Size(90, 32) };
            btnAdd.Click += BtnAdd_Click;

            groupBox.Controls.AddRange(new Control[] { lblFirstName, txtFirstName, lblLastName, txtLastName, btnAdd });

            // Nút Exit ở góc dưới bên phải[cite: 10]
            btnExit = new Button() { Text = "Exit", Location = new Point(440, 325), Size = new Size(100, 32) };
            btnExit.Click += (s, e) => { this.Close(); };

            this.Controls.AddRange(new Control[] { treeView, groupBox, btnExit });
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ First Name và Last Name!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Định dạng hiển thị: "LastName, FirstName" (Ví dụ: Bình, Ngô Thanh)[cite: 10]
            string displayName = $"{lastName}, {firstName}";

            // Lấy chữ cái đầu tiên của Last Name để đưa vào node tương ứng từ A - Z[cite: 10]
            char firstChar = char.ToUpper(lastName[0]);

            if (firstChar >= 'A' && firstChar <= 'Z')
            {
                TreeNode targetNode = treeView.Nodes[firstChar.ToString()];
                if (targetNode != null)
                {
                    targetNode.Nodes.Add(displayName);
                    targetNode.Expand(); // Tự động mở rộng node chữ cái

                    // Xóa trắng ô nhập và đưa con trỏ quay lại First Name để tiếp tục nhập người tiếp theo
                    txtFirstName.Clear();
                    txtLastName.Clear();
                    txtFirstName.Focus();
                }
            }
            else
            {
                MessageBox.Show("Chữ cái đầu tiên của Last Name phải là chữ cái từ A đến Z!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}