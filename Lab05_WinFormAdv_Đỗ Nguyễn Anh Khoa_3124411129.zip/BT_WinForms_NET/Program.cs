using System;
using System.Windows.Forms;

namespace BT_WinForms_NET
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new frmMain());
        }
    }
}