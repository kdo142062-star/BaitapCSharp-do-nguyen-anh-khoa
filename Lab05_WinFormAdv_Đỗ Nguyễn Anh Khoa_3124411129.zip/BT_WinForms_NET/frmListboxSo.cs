using System;
using System.Drawing;
using System.Windows.Forms;

namespace BT_WinForms_NET
{
    public partial class frmListboxSo : Form
    {
        private Label lblHeader, lblGroup1, lblGroup2;
        private TextBox txtSo;
        private Button btnNhap;
        private ListBox lstSo;
        private Button btnTong, btnXoaDauCuoi, btnXoaChon, btnTang2, btnBinhPhuong, btnChonChan, btnChonLe, btnKetThuc;

        public frmListboxSo()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmListbox";
            this.Size = new Size(540, 480);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Tiêu đề chính "LISTBOX"
            lblHeader = new Label() {
                Text = "LISTBOX",
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.OrangeRed,
                Location = new Point(200, 15),
                AutoSize = true
            };

            // Nhóm bên trái: Listbox & Nhập số
            lblGroup1 = new Label() { Text = "Listbox", Location = new Point(25, 55), AutoSize = true, Font = new Font("Arial", 9, FontStyle.Bold) };
            
            txtSo = new TextBox() { Location = new Point(25, 80), Size = new Size(180, 25) };
            // Hỗ trợ nhấn phím Enter để nhập số nhanh
            txtSo.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter)
                {
                    BtnNhap_Click(s, e);
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }
            };

            btnNhap = new Button() { Text = "Nhập", Location = new Point(25, 115), Size = new Size(180, 30) };
            btnNhap.Click += BtnNhap_Click;

            // Listbox hỗ trợ chọn nhiều phần tử (MultiExtended)
            lstSo = new ListBox() { 
                Location = new Point(25, 155), 
                Size = new Size(180, 210),
                SelectionMode = SelectionMode.MultiExtended 
            };

            // Nhóm bên phải: Xử lý Listbox
            lblGroup2 = new Label() { Text = "Xử lý Listbox", Location = new Point(230, 55), AutoSize = true, Font = new Font("Arial", 9, FontStyle.Bold) };

            int bx = 230, by = 80, bw = 265, bh = 32, gap = 6;

            btnTong = new Button() { Text = "Tổng các phần tử trong List", Location = new Point(bx, by), Size = new Size(bw, bh) };
            btnTong.Click += BtnTong_Click;

            btnXoaDauCuoi = new Button() { Text = "Xóa Phần tử đầu và cuối", Location = new Point(bx, by + (bh + gap)), Size = new Size(bw, bh) };
            btnXoaDauCuoi.Click += BtnXoaDauCuoi_Click;

            btnXoaChon = new Button() { Text = "Xóa Phần tử đang chọn", Location = new Point(bx, by + (bh + gap) * 2), Size = new Size(bw, bh) };
            btnXoaChon.Click += BtnXoaChon_Click;

            btnTang2 = new Button() { Text = "Tăng mỗi phần tử lên 2", Location = new Point(bx, by + (bh + gap) * 3), Size = new Size(bw, bh) };
            btnTang2.Click += BtnTang2_Click;

            btnBinhPhuong = new Button() { Text = "Thay bằng bình phương", Location = new Point(bx, by + (bh + gap) * 4), Size = new Size(bw, bh) };
            btnBinhPhuong.Click += BtnBinhPhuong_Click;

            btnChonChan = new Button() { Text = "Chọn số chẵn", Location = new Point(bx, by + (bh + gap) * 5), Size = new Size(bw, bh) };
            btnChonChan.Click += BtnChonChan_Click;

            btnChonLe = new Button() { Text = "Chọn số lẻ", Location = new Point(bx, by + (bh + gap) * 6), Size = new Size(bw, bh) };
            btnChonLe.Click += BtnChonLe_Click;

            // Nút KẾT THÚC ở dưới cùng
            btnKetThuc = new Button() { Text = "KẾT THÚC", Location = new Point(25, 380), Size = new Size(470, 35) };
            btnKetThuc.Click += (s, e) => { this.Close(); };

            this.Controls.AddRange(new Control[] {
                lblHeader, lblGroup1, txtSo, btnNhap, lstSo,
                lblGroup2, btnTong, btnXoaDauCuoi, btnXoaChon, btnTang2, btnBinhPhuong, btnChonChan, btnChonLe, btnKetThuc
            });
        }

        private void BtnNhap_Click(object? sender, EventArgs e)
        {
            if (int.TryParse(txtSo.Text.Trim(), out int val))
            {
                lstSo.Items.Add(val);
                txtSo.Clear();
                txtSo.Focus();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số nguyên hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnTong_Click(object? sender, EventArgs e)
        {
            int sum = 0;
            foreach (var item in lstSo.Items)
            {
                if (item != null && int.TryParse(item.ToString(), out int val))
                {
                    sum += val;
                }
            }
            MessageBox.Show($"Tổng các phần tử trong List: {sum}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnXoaDauCuoi_Click(object? sender, EventArgs e)
        {
            if (lstSo.Items.Count > 0)
            {
                lstSo.Items.RemoveAt(0); // Xóa phần tử đầu
            }
            if (lstSo.Items.Count > 0)
            {
                lstSo.Items.RemoveAt(lstSo.Items.Count - 1); // Xóa phần tử cuối
            }
        }

        private void BtnXoaChon_Click(object? sender, EventArgs e)
        {
            // Duyệt ngược từ dưới lên để tránh lỗi lệch index khi xóa nhiều dòng
            for (int i = lstSo.SelectedItems.Count - 1; i >= 0; i--)
            {
                lstSo.Items.Remove(lstSo.SelectedItems[i]);
            }
        }

        private void BtnTang2_Click(object? sender, EventArgs e)
        {
            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                if (int.TryParse(lstSo.Items[i]?.ToString(), out int val))
                {
                    lstSo.Items[i] = val + 2;
                }
            }
        }

        private void BtnBinhPhuong_Click(object? sender, EventArgs e)
        {
            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                if (int.TryParse(lstSo.Items[i]?.ToString(), out int val))
                {
                    lstSo.Items[i] = val * val;
                }
            }
        }

        private void BtnChonChan_Click(object? sender, EventArgs e)
        {
            lstSo.ClearSelected();
            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                if (int.TryParse(lstSo.Items[i]?.ToString(), out int val) && val % 2 == 0)
                {
                    lstSo.SetSelected(i, true);
                }
            }
        }

        private void BtnChonLe_Click(object? sender, EventArgs e)
        {
            lstSo.ClearSelected();
            for (int i = 0; i < lstSo.Items.Count; i++)
            {
                if (int.TryParse(lstSo.Items[i]?.ToString(), out int val) && val % 2 != 0)
                {
                    lstSo.SetSelected(i, true);
                }
            }
        }
    }
}