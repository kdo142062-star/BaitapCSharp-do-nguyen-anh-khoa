using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace BT_WinForms_NET
{
    public partial class frmTuDien : Form
    {
        private TabControl tabControl;
        private TabPage tabAnhViet, tabVietAnh;
        
        // Tab Anh - Việt
        private ComboBox cboTuAnh;
        private ListBox lstTuAnh;
        private TextBox txtNghiaViet;

        // Tab Việt - Anh
        private ComboBox cboTuViet;
        private ListBox lstTuViet;
        private TextBox txtNghiaAnh;

        private Button btnThoat;

        // Dữ liệu từ điển mẫu
        private Dictionary<string, string> dictAnhViet = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "student", "Sinh viên, học sinh" },
            { "teacher", "Giáo viên" },
            { "worker", "Công nhân" },
            { "hat", "Cái nón, mũ" },
            { "head", "Đầu" },
            { "mouse", "Con chuột" },
            { "cat", "Con mèo" },
            { "dog", "Con chó" },
            { "snake", "Con rắn" },
            { "lamb", "Con cừu non" },
            { "loan", "Khoản vay" },
            { "frog", "Con ếch" },
            { "sheep", "Con cừu" }
        };

        private Dictionary<string, string> dictVietAnh = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "Sinh viên, học sinh", "student" },
            { "Giáo viên", "teacher" },
            { "Công nhân", "worker" },
            { "Cái nón, mũ", "hat" },
            { "Đầu", "head" },
            { "Con chuột", "mouse" },
            { "Con mèo", "cat" },
            { "Con chó", "dog" },
            { "Con rắn", "snake" },
            { "Con cừu non", "lamb" },
            { "Khoản vay", "loan" },
            { "Con ếch", "frog" },
            { "Con cừu", "sheep" }
        };

        public frmTuDien()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "TỪ ĐIỂN ANH VIỆT - VIỆT ANH";
            this.Size = new Size(520, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            tabControl = new TabControl() { Location = new Point(12, 12), Size = new Size(480, 300) };
            tabAnhViet = new TabPage("ANH - VIỆT");
            tabVietAnh = new TabPage("VIỆT - ANH");

            // --- TAB 1: ANH - VIỆT ---
            Label lblTiengAnh = new Label() { Text = "Tiếng Anh", Location = new Point(15, 15), AutoSize = true };
            cboTuAnh = new ComboBox() { 
                Location = new Point(15, 35), 
                Width = 180, 
                AutoCompleteMode = AutoCompleteMode.SuggestAppend, 
                AutoCompleteSource = AutoCompleteSource.ListItems 
            };
            lstTuAnh = new ListBox() { Location = new Point(15, 65), Size = new Size(180, 185) };

            Label lblNghiaViet = new Label() { Text = "Tiếng Việt", Location = new Point(215, 15), AutoSize = true };
            txtNghiaViet = new TextBox() { 
                Location = new Point(215, 35), 
                Size = new Size(235, 215), 
                Multiline = true, 
                ReadOnly = true 
            };

            foreach (var pair in dictAnhViet)
            {
                cboTuAnh.Items.Add(pair.Key);
                lstTuAnh.Items.Add(pair.Key);
            }

            cboTuAnh.SelectedIndexChanged += (s, e) => {
                if (cboTuAnh.SelectedItem != null)
                {
                    string word = cboTuAnh.SelectedItem.ToString() ?? "";
                    lstTuAnh.SelectedItem = word;
                    if (dictAnhViet.ContainsKey(word)) txtNghiaViet.Text = dictAnhViet[word];
                }
            };

            cboTuAnh.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter)
                {
                    string word = cboTuAnh.Text.Trim();
                    if (dictAnhViet.ContainsKey(word))
                    {
                        lstTuAnh.SelectedItem = word;
                        txtNghiaViet.Text = dictAnhViet[word];
                    }
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }
            };

            lstTuAnh.SelectedIndexChanged += (s, e) => {
                if (lstTuAnh.SelectedItem != null)
                {
                    string word = lstTuAnh.SelectedItem.ToString() ?? "";
                    cboTuAnh.Text = word;
                    if (dictAnhViet.ContainsKey(word)) txtNghiaViet.Text = dictAnhViet[word];
                }
            };

            lstTuAnh.DoubleClick += (s, e) => {
                if (lstTuAnh.SelectedItem != null)
                {
                    string word = lstTuAnh.SelectedItem.ToString() ?? "";
                    cboTuAnh.Text = word;
                    if (dictAnhViet.ContainsKey(word)) txtNghiaViet.Text = dictAnhViet[word];
                }
            };

            tabAnhViet.Controls.AddRange(new Control[] { lblTiengAnh, cboTuAnh, lstTuAnh, lblNghiaViet, txtNghiaViet });


            // --- TAB 2: VIỆT - ANH ---
            Label lblTiengViet = new Label() { Text = "Tiếng Việt", Location = new Point(15, 15), AutoSize = true };
            cboTuViet = new ComboBox() { 
                Location = new Point(15, 35), 
                Width = 180, 
                AutoCompleteMode = AutoCompleteMode.SuggestAppend, 
                AutoCompleteSource = AutoCompleteSource.ListItems 
            };
            lstTuViet = new ListBox() { Location = new Point(15, 65), Size = new Size(180, 185) };

            Label lblNghiaAnh = new Label() { Text = "Tiếng Anh", Location = new Point(215, 15), AutoSize = true };
            txtNghiaAnh = new TextBox() { 
                Location = new Point(215, 35), 
                Size = new Size(235, 215), 
                Multiline = true, 
                ReadOnly = true 
            };

            foreach (var pair in dictVietAnh)
            {
                cboTuViet.Items.Add(pair.Key);
                lstTuViet.Items.Add(pair.Key);
            }

            cboTuViet.SelectedIndexChanged += (s, e) => {
                if (cboTuViet.SelectedItem != null)
                {
                    string word = cboTuViet.SelectedItem.ToString() ?? "";
                    lstTuViet.SelectedItem = word;
                    if (dictVietAnh.ContainsKey(word)) txtNghiaAnh.Text = dictVietAnh[word];
                }
            };

            cboTuViet.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter)
                {
                    string word = cboTuViet.Text.Trim();
                    if (dictVietAnh.ContainsKey(word))
                    {
                        lstTuViet.SelectedItem = word;
                        txtNghiaAnh.Text = dictVietAnh[word];
                    }
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }
            };

            lstTuViet.SelectedIndexChanged += (s, e) => {
                if (lstTuViet.SelectedItem != null)
                {
                    string word = lstTuViet.SelectedItem.ToString() ?? "";
                    cboTuViet.Text = word;
                    if (dictVietAnh.ContainsKey(word)) txtNghiaAnh.Text = dictVietAnh[word];
                }
            };

            lstTuViet.DoubleClick += (s, e) => {
                if (lstTuViet.SelectedItem != null)
                {
                    string word = lstTuViet.SelectedItem.ToString() ?? "";
                    cboTuViet.Text = word;
                    if (dictVietAnh.ContainsKey(word)) txtNghiaAnh.Text = dictVietAnh[word];
                }
            };

            tabVietAnh.Controls.AddRange(new Control[] { lblTiengViet, cboTuViet, lstTuViet, lblNghiaAnh, txtNghiaAnh });

            tabControl.TabPages.Add(tabAnhViet);
            tabControl.TabPages.Add(tabVietAnh);

            btnThoat = new Button() { Text = "Thoát", Location = new Point(392, 322), Size = new Size(100, 30) };
            btnThoat.Click += (s, e) => { this.Close(); };

            this.Controls.AddRange(new Control[] { tabControl, btnThoat });
        }
    }
}