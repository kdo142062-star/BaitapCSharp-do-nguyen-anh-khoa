using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace BT_WinForms_NET
{
    public partial class frmLop : Form
    {
        private TextBox txtMaKhoa, txtMaLop, txtTenLop;
        private Button btnThem, btnXoa, btnSua;
        private string connString = @"Server=.\SQLEXPRESS;Database=QLSINHVIEN;Trusted_Connection=True;TrustServerCertificate=True;";

        public frmLop()
        {
            InitializeComponentCustom();
        }

        private void InitializeComponentCustom()
        {
            this.Text = "frmLop - Quản lý Lớp";
            this.Size = new Size(420, 310);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblMaKhoa = new Label() { Text = "Mã khoa", Location = new Point(30, 30), AutoSize = true };
            txtMaKhoa = new TextBox() { Location = new Point(120, 28), Width = 250 };
            txtMaKhoa.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) { txtMaLop.Focus(); e.Handled = true; e.SuppressKeyPress = true; }
            };

            Label lblMaLop = new Label() { Text = "Mã lớp", Location = new Point(30, 75), AutoSize = true };
            txtMaLop = new TextBox() { Location = new Point(120, 73), Width = 250 };
            txtMaLop.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) { txtTenLop.Focus(); e.Handled = true; e.SuppressKeyPress = true; }
            };

            Label lblTenLop = new Label() { Text = "Tên lớp", Location = new Point(30, 120), AutoSize = true };
            txtTenLop = new TextBox() { Location = new Point(120, 118), Width = 250 };
            txtTenLop.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) { BtnThem_Click(s, e); e.Handled = true; e.SuppressKeyPress = true; }
            };

            btnThem = new Button() { Text = "Thêm", Location = new Point(45, 185), Width = 95, Height = 35 };
            btnThem.Click += BtnThem_Click;

            btnXoa = new Button() { Text = "Xóa", Location = new Point(155, 185), Width = 95, Height = 35 };
            btnXoa.Click += BtnXoa_Click;

            btnSua = new Button() { Text = "Sửa", Location = new Point(265, 185), Width = 95, Height = 35 };
            btnSua.Click += BtnSua_Click;

            this.Controls.AddRange(new Control[] {
                lblMaKhoa, txtMaKhoa, lblMaLop, txtMaLop, lblTenLop, txtTenLop, btnThem, btnXoa, btnSua
            });
        }

        private void BtnThem_Click(object? sender, EventArgs e)
        {
            string maKhoa = txtMaKhoa.Text.Trim();
            string maLop = txtMaLop.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (string.IsNullOrEmpty(maKhoa) || string.IsNullOrEmpty(maLop) || string.IsNullOrEmpty(tenLop))
            {
                MessageBox.Show("Mã khoa, Mã lớp và Tên lớp không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btnThem.Enabled = false;
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "INSERT INTO Lop (MaKhoa, MaLop, TenLop) VALUES (@MaKhoa, @MaLop, @TenLop)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);
                        cmd.Parameters.AddWithValue("@MaLop", maLop);
                        cmd.Parameters.AddWithValue("@TenLop", tenLop);
                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Thêm mới lớp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearInputs();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnThem.Enabled = true;
            }
        }

        private void BtnXoa_Click(object? sender, EventArgs e)
        {
            string maLop = txtMaLop.Text.Trim();
            if (string.IsNullOrEmpty(maLop))
            {
                MessageBox.Show("Vui lòng nhập Mã lớp cần xóa!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaLop.Focus();
                return;
            }

            if (MessageBox.Show($"Bạn có chắc muốn xóa lớp '{maLop}' không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                btnXoa.Enabled = false;
                try
                {
                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        conn.Open();
                        string query = "DELETE FROM Lop WHERE MaLop = @MaLop";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@MaLop", maLop);
                            int rows = cmd.ExecuteNonQuery();
                            if (rows > 0)
                            {
                                MessageBox.Show("Xóa thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearInputs();
                            }
                            else
                            {
                                MessageBox.Show("Không tìm thấy Mã lớp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
                finally
                {
                    btnXoa.Enabled = true;
                }
            }
        }

        private void BtnSua_Click(object? sender, EventArgs e)
        {
            string maLop = txtMaLop.Text.Trim();
            string maKhoa = txtMaKhoa.Text.Trim();
            string tenLop = txtTenLop.Text.Trim();

            if (string.IsNullOrEmpty(maLop))
            {
                MessageBox.Show("Mã lớp không được để trống khi sửa!");
                return;
            }

            btnSua.Enabled = false;
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    string query = "UPDATE Lop SET MaKhoa = @MaKhoa, TenLop = @TenLop WHERE MaLop = @MaLop";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaLop", maLop);
                        cmd.Parameters.AddWithValue("@MaKhoa", maKhoa);
                        cmd.Parameters.AddWithValue("@TenLop", tenLop);
                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Cập nhật thành công!");
                            ClearInputs();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy Mã lớp cần sửa!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                btnSua.Enabled = true;
            }
        }

        private void ClearInputs()
        {
            txtMaKhoa.Clear();
            txtMaLop.Clear();
            txtTenLop.Clear();
            txtMaKhoa.Focus();
        }
    }
}